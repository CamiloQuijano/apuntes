<?php

namespace AT\AdminBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AT\AdminBundle\Entity\AtToken
 *
 * @ORM\Table(name="at_token")
 * @ORM\Entity
 */
class AtToken
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var text $token
     *
     * @ORM\Column(name="token", type="text", nullable=false)
     */
    private $token;

    /**
     * @var string $email
     *
     * @ORM\Column(name="email", type="string", length=500, nullable=false)
     */
    private $email;

    /**
     * @var datetime $vence
     *
     * @ORM\Column(name="vence", type="datetime", nullable=false)
     */
    private $vence;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set token
     *
     * @param text $token
     */
    public function setToken($token)
    {
        $this->token = $token;
    }

    /**
     * Get token
     *
     * @return text 
     */
    public function getToken()
    {
        return $this->token;
    }

    /**
     * Set email
     *
     * @param string $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set vence
     *
     * @param datetime $vence
     */
    public function setVence($vence)
    {
        $this->vence = $vence;
    }

    /**
     * Get vence
     *
     * @return datetime 
     */
    public function getVence()
    {
        return $this->vence;
    }
}