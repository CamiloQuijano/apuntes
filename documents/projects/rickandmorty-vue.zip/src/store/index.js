import { createStore } from 'vuex'

export default createStore({
  // Variables dinámicas
  state: {
    quantityFilter: 0,
    characters: [],  // Listado de personajes
    charactersFilters: []       // Listado de personajes (Filtrado)
  },

  // Modificar las variables
  mutations: {

    /**
     * Actualizar caracteres (Listado Completo)
     * @param {*} state Estado para acceder a variable
     * @param {*} payload data a enviar
     */
    setCharacters(state, payload) {
      //state.characters = payload;
      payload.map((char) => { state.characters.push(char); });
    },

    /**
     * Actualizar caracteres (Listado Filtrado)
     * @param {*} state Estado para acceder a variable
     * @param {*} payload Listado de caracteres
     */
     setCharactersFilters(state, payload) {
      //state.charactersFilters = payload;
      payload.map((char) => { state.charactersFilters.push(char); });
    },

    /**
     * Actualizar caracteres (Listado Filtrado - resetenado listado)
     * @param {*} state Estado para acceder a variable
     * @param {*} payload Listado de caracteres
     */
    setCharactersFiltersWithReset(state, payload) {
      state.charactersFilters = [];
      //state.charactersFilters = payload;
      payload.map((char) => { state.charactersFilters.push(char); });
    },

    /**
     * Actualizar cantidad de registros 
     * @param {*} state Estado para acceder a variable
     */
    setQuantityFilter(state) {
      state.quantityFilter = state.charactersFilters.length;
    }
  },

  // Funcion que llama las funciones de mutacion
  actions: {

    // Función que se encarga de conectarse al api y traer la información
    async getCharacters({commit}) {
      try {

        // Conectar a api, para acceder a información
        const response = await fetch('https://rickandmortyapi.com/api/character')
        const data = await response.json()

        // Ejecutar las mutations, y asignar el valor
        commit('setCharacters', data.results);
        commit('setCharactersFilters', data.results);
        commit('setQuantityFilter');
        
        let pages = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
        for await (const page of pages) {
          // Conectar a api, para acceder a información
          const responseAdd = await fetch('https://rickandmortyapi.com/api/character/?page='+page)
          const dataAdd = await responseAdd.json()

          // Ejecutar las mutations, y asignar el valor
          commit('setCharacters', dataAdd.results);
          commit('setCharactersFilters', dataAdd.results);
          commit('setQuantityFilter');
        }

      } catch (error) {
        console.error(error);
      }
    },

    /**
     * Funcion que se encarga de controlar el click de los filtros
     * @param {*} param0 Acceso a mutations
     * @param {*} stateFilter Estado a filtrar
     */
    filterByStatus({commit, state}, stateFilter) {

      // Aplica filtro
      const resultFilter = state.characters.filter((character) => {
        return character.status.includes(stateFilter)
      });

      // Actualiza variable llamando mutacion
      commit('setCharactersFiltersWithReset', resultFilter);
      commit('setQuantityFilter', resultFilter);

    },

    /**
     * Filtrar por nombre (se ejecuta x keyUp)
     * @param {*} param0 Acceso a mutations
     * @param {*} seachName Nombre a buscar
     */
    filterByName({commit, state}, searchName) {
      const nameSearchLower = searchName.toLowerCase() // Pasar a minuscula texto a buscar
      // Aplica filtro
      const resultFilter = state.characters.filter((character) => {
        const nameCharacter = character.name.toLowerCase() // Pasar a minuscula texto a buscar
        if(nameCharacter.includes(nameSearchLower)) {
          return character
        }
        
      });

      // Actualiza variable llamando mutacion
      commit('setCharactersFiltersWithReset', resultFilter);
      commit('setQuantityFilter', resultFilter);

    }

  },

  modules: {
  }
})
