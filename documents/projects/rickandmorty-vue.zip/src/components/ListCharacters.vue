<template>
    <section>
        <div class="characters">
            <div class="characters__item" v-for="character in characters" :key="character.id">
                <CardCharacter :character="character" />
            </div>
        </div>
    </section>
</template>

<script>

import { onMounted, onUpdated, onUnmounted, onBeforeMount,  computed } from 'vue'
import { useStore } from 'vuex';
import CardCharacter from '@/components/CardCharacter'

export default {
    components: {
        CardCharacter
    },
    setup() {

        // Definir uso de STORE
        const store = useStore();
        const characters = computed(() => {
            return store.state.charactersFilters;
        });

        // Evento antes de iniciar
        onBeforeMount(() => {
            console.log('Status: onBeforeMount!')
        })

        // Apena inicie
        onMounted(() => {
            store.dispatch('getCharacters');
        });

        // Al actualizar alguna variable
        onUpdated(() => {
            console.log('Status: updated!')
        })
        
        // Al desmontar funcionalidad
        onUnmounted(() => {
            console.log('Status: unmounted!')
        })

        // Variables de uso en template
        return {
            characters
        }
    }

}
</script>

<style>
    .characters {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 3rem;
        margin: 3rem 0;
    }
</style>