<template>
<div class="search">
    <input type="text"
        placeholder="Buscar por nombre"
        v-model="name"
        @keyup="filterName()" >
</div>

</template>

<script>
    import { ref } from 'vue' // Acceder a variables en uso en vista
    import { useStore } from 'vuex'

    export default {
        setup() {

            // Definir uso de STORE
            const store = useStore()
            const name = ref('')

            // Función que controlará el evento click del filtro
            const filterName = (() => {
                store.dispatch('filterByName', name.value);
            });
            
            // Retorno de funciones para uso
            return {
                name,   // Variable de vista
                filterName
            }
        }
    }

</script>

<style lang="scss">
    .search {
        width: 400px;
        input {
            height: 53px;
            width: 400px;
            border: none;
            border-radius: 10px;
            padding: 0 0.5rem;
        }
    }
</style>